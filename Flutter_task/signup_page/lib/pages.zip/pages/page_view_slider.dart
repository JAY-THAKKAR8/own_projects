import 'package:flutter/material.dart';
import 'package:signup_page/pages/Page1.dart';
import 'package:signup_page/pages/Page2.dart';
import 'package:signup_page/pages/Page3.dart';

class MyStatelessWidget extends StatelessWidget {
  const MyStatelessWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final PageController controller = PageController();
    return PageView(
                  /// [PageView.scrollDirection] defaults to [Axis.horizontal].
      /// Use [Axis.vertical] to scroll vertically.
      controller: controller,
      scrollDirection: Axis.horizontal,
      children: [
          Page1(),
          Page2(),
          Page3(),
      ],
    );
  }
}

